package com.ys.service.crawler.impl;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestParam;

import com.ys.dao.C39netDiseaseBaseurlMapper;
import com.ys.dao.JbInfoMapper;
import com.ys.dao.JbZhengzhuangMapper;
import com.ys.dao.TaskHistoryLogErrorMapper;
import com.ys.dao.TaskHistoryLogMapper;
import com.ys.exception.BusinessException;
import com.ys.model.C39netDiseaseBaseurl;
import com.ys.model.JbInfo;
import com.ys.model.JbInfoExample;
import com.ys.model.JbZhengzhuang;
import com.ys.model.JbZhengzhuangExample;
import com.ys.model.TaskHistoryLog;
import com.ys.model.TaskHistoryLogError;
import com.ys.service.crawler.IC39netService;

@Service
@Transactional
public class C39netService implements IC39netService {
	private final String SITE_URL_ = "www.39.net/";
	@Resource
	private C39netDiseaseBaseurlMapper c39netDiseaseBaseurlDao;
	@Resource
	private TaskHistoryLogMapper taskHistoryLogDao;
	@Resource
	private TaskHistoryLogErrorMapper taskHistoryLogErrorDao;
	@Resource
	private JbInfoMapper jbInfoDao;
	@Resource
	private JbZhengzhuangMapper jbZhengzhuangDao;
	
	private Document getDocument(String gourl) throws IOException {
		// String ip="";
		// System.getProperties().setProperty("http.proxyHost", ip);
		// System.getProperties().setProperty("http.proxyPort", "8080");
		// Document doc=Jsoup.connect(gourl).get();
		Document doc = Jsoup.parse(new URL(gourl).openStream(), "GBK", gourl);
		return doc;
	}

	@Override
	public void crawerUrl(int beginPage, int endPage) throws Exception {
		String templete_url = "http://jbk.39.net/bw_p%d#ps";
		TaskHistoryLog record = new TaskHistoryLog();
		record.setBeginPage(beginPage);
		record.setEndPage(endPage);
		record.setSiteUrl(SITE_URL_);
		record.setTaskType("index_url");
		record.setTaskUrl(templete_url);
		taskHistoryLogDao.insert(record);

	 
		for (int i = beginPage; i < endPage; i++) {
			String gourl = null;
			if (i == 0) {
				gourl = "http://jbk.39.net/bw";
			} else {
				gourl = String.format(templete_url, i);
			}
	 
				Document doc = getDocument(gourl);
				Elements as = doc.getElementById("res_tab_1").getElementsByClass("res_list");
				for (Element e : as) {
					Element a = e.getElementsByTag("h3").get(0).getElementsByTag("a").get(0);
					C39netDiseaseBaseurl u = new C39netDiseaseBaseurl();
					String href=a.attr("href").replace("http://jbk.39.net", "");
					u.setUrl(href);
					String[] urls=href.split("/");
					if(urls.length==2){
						u.setDaima(urls[1]);
					}
					if(urls.length==3){
						u.setDaima(urls[2]);
					}
					if(href.contains("zhengzhuang")){
						u.setType("zhengzhuang");
					}else
					{
						u.setType("jibing");
					}
					try{
						c39netDiseaseBaseurlDao.insert(u);
					}catch(Exception ex){
						ex.printStackTrace();
						TaskHistoryLogError log = new TaskHistoryLogError();
						log.setSiteUrl(SITE_URL_);
						log.setStatus(Short.parseShort("0"));
						log.setTaskUrl(gourl);
						log.setTaskType("index_url");
						log.setErrorInfo(ex.getMessage());
						taskHistoryLogErrorDao.insert(log);
					}
				}
		}
		 
	}

	private String filterHyperlink(Elements las) {
		String returnString = "";
		for (Element a : las) {
			String content = a.outerHtml().trim();
			String to = "";
			if (a.text().contains("详细")) {
				continue;
			}
			to = content.replace("http://jbk.39.net", "");
			returnString += to;
		}
		return returnString;
	}

	private String filterHyperlinkTitle(Elements las) {
		String returnString = "";
		for (Element a : las) {
			if (a.attr("class").equals("more")) {
				continue;
			}
			if (StringUtils.isBlank(a.attr("title"))) {
				returnString += a.text() + ";";
			}
			if (StringUtils.isNotBlank(a.attr("title"))) {
				returnString += a.attr("title") + ";";
			}
		}
		return returnString;
	}

	private String getUrlTitle(String url) {
		String[] as = url.split("/");
		return as.length > 2 ? as[as.length - 2] : "";
	}

	private String getUrlBuwei(String url) {
		String[] as = url.split("/");
		return as.length > 2 ? as[as.length - 1] : "";
	}

	@Override
	public void crawlDiseaseInfo(String url) {
		TaskHistoryLog record = new TaskHistoryLog();
		record.setSiteUrl(SITE_URL_);
		record.setTaskType("jb_xiangxi");
		record.setTaskUrl(url);
		taskHistoryLogDao.insert(record);
		String templete_url = url + "%s";
		try {
			JbInfo jbInfo = crawerJBJJ(String.format(templete_url, "jbzs"));
			crawerDXZZ(String.format(templete_url, "zztz"), jbInfo);// 典型症状
			crawerFBYY(String.format(templete_url, "blby"), jbInfo);// 发病原因
			crawerYF(String.format(templete_url, "yfhl"), jbInfo);// 预防
			crawerJIANCHA(String.format(templete_url, "jcjb"), jbInfo);// 临床检查
			crawerJIANBIE(String.format(templete_url, "jb"), jbInfo);// 鉴别
			crawerZHILIAOFANGFA(String.format(templete_url, "yyzl"), jbInfo);// 治疗方法
			crawerHULI(String.format(templete_url, "hl"), jbInfo);// 护理
			crawerYSBJ(String.format(templete_url, "ysbj"), jbInfo);// 饮食保健
			crawerBFZ(String.format(templete_url, "bfbz"), jbInfo);// 并发症
			jbInfoDao.insert(jbInfo);
		} catch (Exception e) {
			e.printStackTrace();
			TaskHistoryLogError log = new TaskHistoryLogError();
			log.setSiteUrl(SITE_URL_);
			log.setStatus(Short.parseShort("0"));
			log.setTaskUrl(url);
			log.setTaskType("jb_xiangxi");
			log.setErrorInfo(e.getMessage());
			taskHistoryLogErrorDao.insert(log);
		}
	}

	/**
	 * 疾病简介
	 * 
	 * @param url
	 * @return
	 * @throws Exception
	 */
	private JbInfo crawerJBJJ(String url) throws Exception {
		JbInfo jbInfo = new JbInfo();
		try {
			Document doc = getDocument(url);
			String daima = getUrlTitle(url);
			jbInfo.setDaima(daima);
			Elements ele = doc.getElementsByClass("tit clearfix");
			if (ele.size() > 0) {
				Element title = ele.get(0);
				String mingcheng = title.text().trim();
				jbInfo.setMingcheng(mingcheng);
			} else {
				throw new BusinessException("mingcheng is error");
			}
			Elements dls;
			try {
				Elements secs = doc.getElementsByClass("chronic wrap");
				Element div = secs.get(0).getElementsByClass("content clearfix").get(0);
				Element targetDiv = div.getElementsByClass("chi-know").get(0);
				dls = targetDiv.getElementsByTag("dl");
			} catch (Exception e) {
				throw new BusinessException("jianjie liebiao is error");
			}
			// jianjie
			Elements eles = dls.get(0).getElementsByIndexEquals(1);
			if (eles.size() > 0) {
				String jianjie = StringUtils.deleteWhitespace(eles.text());
				jbInfo.setJianjie(jianjie);
			}
			// jibinzhishi
			if (dls.get(1) == null) {
				throw new BusinessException("jibiezhishi is error");
			}
			Elements dds = dls.get(1).getElementsByTag("dd");
			if (dds.size() == 0) {
				throw new BusinessException("jibiezhishi liebiao is error");
			}
			dds.select("i").remove();
			Short yibao = dds.get(0).text().trim().equals("医保疾病") ? Short.parseShort("1") : Short.parseShort("0");
			jbInfo.setYibao(yibao);
			if (dds.size() == 7) {
				String bieming = dds.get(1).text().trim();
				jbInfo.setBieming(bieming);
				String fabingbuwei = dds.get(2).html().trim();
				jbInfo.setFabingbuwei(fabingbuwei);
				eles = dds.get(2).getElementsByIndexEquals(0);
				if (eles.size() > 0) {
					String buwei = getUrlBuwei(eles.attr("href"));
					jbInfo.setBuwei(buwei);
				}
				Short chuanranxing = dds.get(3).text().trim().equals("有传染性") ? Short.parseShort("1")
						: Short.parseShort("0");
				jbInfo.setChuanranxing(chuanranxing);
				String duofarenqun = dds.get(4).html().trim();
				jbInfo.setDuofarenqun(duofarenqun);
				Elements las = dds.get(5).getElementsByTag("a");
				if (las.size() > 0) {
					String xiangguanzhengzhuang = filterHyperlink(las);
					jbInfo.setXiangguanzhengzhuang(xiangguanzhengzhuang);
				}
				las = dds.get(6).getElementsByTag("a");
				if (las.size() > 0) {
					String bingfajibing = filterHyperlink(las);
					jbInfo.setBingfajibing(bingfajibing);
				}
			} else {
				jbInfo.setBieming("");
				String fabingbuwei = dds.get(1).html().trim();
				jbInfo.setFabingbuwei(fabingbuwei);
				eles = dds.get(1).getElementsByIndexEquals(0);
				if (eles.size() > 0) {
					String buwei = getUrlBuwei(eles.attr("href"));
					jbInfo.setBuwei(buwei);
				}
				Short chuanranxing = dds.get(2).text().trim().equals("有传染性") ? Short.parseShort("1")
						: Short.parseShort("0");
				jbInfo.setChuanranxing(chuanranxing);
				String duofarenqun = dds.get(3).html().trim();
				jbInfo.setDuofarenqun(duofarenqun);
				Elements las = dds.get(4).getElementsByTag("a");
				if (las.size() > 0) {
					String xiangguanzhengzhuang = filterHyperlink(las);
					jbInfo.setXiangguanzhengzhuang(xiangguanzhengzhuang);
				}
				las = dds.get(5).getElementsByTag("a");
				if (las.size() > 0) {
					String bingfajibing = filterHyperlink(las);
					jbInfo.setBingfajibing(bingfajibing);
				}
			}

			// zhenliao
			if (dls.size() >= 3) {
				dds = dls.get(2).getElementsByTag("dd");
				dds.select("i").remove();
				if (dds.size() > 0) {
					if (dds.size() >= 1) {
						String jiuzhenkeshi = dds.get(0).html().trim();
						jbInfo.setJiuzhenkeshi(jiuzhenkeshi);
					}
					if (dds.size() >= 2) {
						String zhiliaofeiyong = dds.get(1).html().trim();
						jbInfo.setZhiliaofeiyong(zhiliaofeiyong);
					}
					if (dds.size() >= 3) {
						String zhiyulv = dds.get(2).html().trim();
						jbInfo.setZhiyulv(zhiyulv);
					}
					if (dds.size() >= 4) {
						String zhiliaozhouqi = dds.get(3).html().trim();
						jbInfo.setZhiliaozhouqi(zhiliaozhouqi);
					}
					if (dds.size() >= 5) {
						Elements las = dds.get(4).getElementsByTag("a");
						if (las.size() > 0) {
							String zhiliaofangfa = filterHyperlink(las);
							jbInfo.setZhiliaofangfa(zhiliaofangfa);
						}
					}
					if (dds.size() >= 6) {
						Elements las = dds.get(5).getElementsByTag("a");
						if (las.size() > 0) {
							String xiangguanjiancha = filterHyperlink(las);
							jbInfo.setXiangguanjiancha(xiangguanjiancha);
						}
					}
					if (dds.size() == 7) {
						Elements las = dds.get(6).getElementsByTag("a");
						if (las.size() > 0) {
							String changyongyaopin = filterHyperlinkTitle(las);
							jbInfo.setChangyongyaopin(changyongyaopin);
						}
					}
					if (dds.size() == 8) {
						Elements las = dds.get(7).getElementsByTag("a");
						if (las.size() > 0) {
							String changyongyaopin = filterHyperlinkTitle(las);
							jbInfo.setChangyongyaopin(changyongyaopin);
						}
						las = dds.get(6).getElementsByTag("a");
						if (las.size() > 0) {
							String xiangguanshoushu = filterHyperlinkTitle(las);
							jbInfo.setXiangguanshoushu(xiangguanshoushu);
						}
					}
				}
			}

			// yiyuan
			if (dls.size() >= 4) {
				dds = dls.get(3).getElementsByTag("dd");
				dds.select("i").remove();
				if (dds.size() > 0) {
					dds.get(0).select("a").remove();
					String zuijiajiuzhen = dds.get(0).html().trim();
					jbInfo.setZuijiajiuzhen(zuijiajiuzhen);
				}
				if (dds.size() >= 2) {
					dds.get(1).select("a").remove();
					String jiuzhenshichang = dds.get(1).html().trim();
					jbInfo.setJiuzhenshichang(jiuzhenshichang);
				}
				if (dds.size() >= 3) {
					String zhenliaozhouqi = dds.get(2).html().trim();
					jbInfo.setZhenliaozhouqi(zhenliaozhouqi);
				}
				if (dds.size() >= 4) {
					dds.get(3).select("a").remove();
					String zhenqianzhunbei = dds.get(3).html().trim();
					jbInfo.setZhenqianzhunbei(zhenqianzhunbei);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return jbInfo;
	}

	/**
	 * 典型症状
	 * 
	 * @param url
	 * @param jbInfo
	 * @return
	 * @throws Exception
	 **/
	private JbInfo crawerDXZZ(String url, JbInfo jbInfo) throws Exception {
		StringBuffer info = new StringBuffer();
		Document doc = getDocument(url);
		Elements eles = doc.getElementsByClass("links");
		if (eles.size() <= 0) {
			return jbInfo;
		}
		Elements infos = eles.get(0).getElementsByTag("dd");
		if (infos.size() <= 0) {
			return jbInfo;
		}

		String dxzz = infos.get(0).html().trim();
		info.append("<div>" + dxzz + "</div>");

		if (infos.size() >= 1) {
			String xxzz = infos.get(1).html().trim();
			xxzz = xxzz.replace("http://jbk.39.net", "");
			info.append("<div>" + xxzz + "</div>");
		}
		infos = doc.getElementsByClass("art-box");
		if (infos.size() > 0) {
			Elements ps = infos.get(0).getElementsByTag("p");
			if (ps.size() > 0) {
				for (Element element : ps) {
					if (element.attr("class").equals("target")) {
						info.append("<div class=\"title\">" + element.text() + "</div>");
					} else {
						info.append("<div>" + element.text() + "</div>");
					}
				}
			}
		}

		jbInfo.setZhengzhuang(info.toString());
		return jbInfo;
	}

	/**
	 * 发病原因
	 * 
	 * @param url
	 * @param jbInfo
	 * @return
	 * @throws Exception
	 */
	private JbInfo crawerFBYY(String url, JbInfo jbInfo) throws Exception {
		Document doc = getDocument(url);
		Elements eles = doc.getElementsByClass("art-box");

		if (eles.size() <= 0) {
			return jbInfo;
		}
		Elements ps = eles.get(0).getElementsByTag("p");
		if (ps.size() <= 0) {
			return jbInfo;
		}

		StringBuffer info = new StringBuffer();
		for (Element element : ps) {
			if (element.attr("class").equals("target")) {
				info.append("<div class=\"title\">" + element.text() + "</div>");
			} else {
				info.append("<div>" + element.text() + "</div>");
			}
		}
		jbInfo.setFabingyuanyin(info.toString());
		return jbInfo;

	}

	/**
	 * 预防
	 * 
	 * @param url
	 * @param jbInfo
	 * @return
	 * @throws Exception
	 */
	private JbInfo crawerYF(String url, JbInfo jbInfo) throws Exception {

		StringBuffer info = new StringBuffer();
		Document doc = getDocument(url);
		Elements eles = doc.getElementsByClass("art-box");
		if (eles.size() <= 0) {
			return jbInfo;
		}
		Elements ps = eles.get(0).getElementsByTag("p");
		if (ps.size() <= 0) {
			return jbInfo;
		}
		for (Element element : ps) {
			if (element.attr("class").equals("target")) {
				info.append("<div class=\"title\">" + element.text() + "</div>");
			} else {
				info.append("<div>" + element.text() + "</div>");
			}
		}
		jbInfo.setYufang(info.toString());
		return jbInfo;
	}

	/**
	 * 临床检查
	 * 
	 * @param url
	 * @param jbInfo
	 * @return
	 * @throws Exception
	 */
	private JbInfo crawerJIANCHA(String url, JbInfo jbInfo) throws Exception {
		StringBuffer info = new StringBuffer();
		Document doc = getDocument(url);
		Elements eles = doc.getElementsByClass("checkbox");

		if (eles.size() <= 0l) {
			return jbInfo;
		}
		Element div = eles.get(0);
		info.append(div.html().trim().replace("http://jbk.39.net", ""));
		eles = doc.getElementsByClass("links");
		if (eles.size() <= 0) {
			div = eles.get(0);
			info.append("<div>" + div.text().trim() + "</div>");
		}
		eles = doc.getElementsByClass("art-box");
		if (eles.size() > 0) {
			Elements ps = eles.get(0).getElementsByTag("p");
			if (ps.size() > 0) {
				for (Element element : ps) {
					if (element.attr("class").equals("target")) {
						info.append("<div class=\"title\">" + element.text() + "</div>");
					} else {
						info.append("<div>" + element.text() + "</div>");
					}
				}
			}
		}
		jbInfo.setLinchuangjiancha(info.toString());
		return jbInfo;
	}

	/**
	 * 鉴别
	 * 
	 * @param url
	 * @param jbInfo
	 * @return
	 * @throws Exception
	 */
	private JbInfo crawerJIANBIE(String url, JbInfo jbInfo) throws Exception {
		StringBuffer info = new StringBuffer();
		Document doc = getDocument(url);
		Elements eles = doc.getElementsByClass("art-box");
		if (eles.size() <= 0) {
			return jbInfo;
		}
		Elements ps = eles.get(0).getElementsByTag("p");
		if (ps.size() <= 0) {
			return jbInfo;
		}

		for (Element element : ps) {
			if (element.attr("class").equals("target")) {
				info.append("<div class=\"title\">" + element.text() + "</div>");
			} else {
				info.append("<div>" + element.text() + "</div>");
			}
		}
		jbInfo.setJianbie(info.toString());
		return jbInfo;
	}

	/**
	 * 治疗方法
	 * 
	 * @param url
	 * @param jbInfo
	 * @return
	 * @throws Exception
	 */
	private JbInfo crawerZHILIAOFANGFA(String url, JbInfo jbInfo) throws Exception {
		StringBuffer info = new StringBuffer();
		Document doc = getDocument(url);

		Elements eles = doc.getElementsByClass("info");
		if (eles.size() <= 0) {
			return jbInfo;
		}

		Elements lls = eles.get(0).getElementsByTag("dt");
		if (lls.size() <= 0) {
			return jbInfo;
		}

		Element dl = eles.get(0);
		Element dt = lls.get(0);
		info.append("<div>" + dt.text() + "</div>");

		Elements dds = dl.getElementsByTag("dd");
		for (Element dd : dds) {
			info.append("<div>" + dd.html().trim() + "</div>");
		}
		if (doc.getElementsByClass("art-box") != null) {
			if (doc.getElementsByClass("art-box").get(0) != null) {
				if (doc.getElementsByClass("art-box").get(0).getElementsByTag("p") != null) {
					Element div = doc.getElementsByClass("art-box").get(0);
					Elements ps = div.getElementsByTag("p");
					for (Element element : ps) {
						if (element.attr("class").equals("target")) {
							info.append("<div class=\"title\">" + element.text() + "</div>");
						} else {
							info.append("<div>" + element.text() + "</div>");
						}
					}

				}
			}
		}
		jbInfo.setZhiliao(info.toString());
		return jbInfo;

	}

	/**
	 * 护理
	 * 
	 * @param url
	 * @param jbInfo
	 * @return
	 * @throws Exception
	 */
	private JbInfo crawerHULI(String url, JbInfo jbInfo) throws Exception {
		StringBuffer info = new StringBuffer();
		Document doc = getDocument(url);
		Elements eles = doc.getElementsByClass("art-box");
		if (eles.size() <= 0) {
			return jbInfo;
		}
		Elements ps = eles.get(0).getElementsByTag("p");
		if (ps.size() <= 0) {
			return jbInfo;
		}

		for (Element element : ps) {
			if (element.attr("class").equals("target")) {
				info.append("<div class=\"title\">" + element.text() + "</div>");
			} else {
				info.append("<div>" + element.text() + "</div>");
			}
		}
		jbInfo.setHuli(info.toString());
		return jbInfo;

	}

	/**
	 * 饮食保健
	 * 
	 * @param url
	 * @param jbInfo
	 * @return
	 * @throws Exception
	 **/
	private JbInfo crawerYSBJ(String url, JbInfo jbInfo) throws Exception {

		StringBuffer info = new StringBuffer();
		Document doc = getDocument(url);
		Elements eles = doc.getElementsByClass("links");
		if (eles.size() <= 0) {
			return jbInfo;
		}
		Element dt = eles.get(0);
		info.append("<div>" + dt.text().trim() + "</div>");
		eles = doc.getElementsByClass("yinshi_table");
		if (eles.size() > 0) {
			Element jz = eles.get(0);
			info.append(jz.html().trim());
		}
		eles = doc.getElementsByClass("art-box");
		if (eles.size() > 0) {
			Element div = eles.get(1);
			Elements dds = div.getElementsByTag("dl");
			if (dds.size() > 0) {
				Element tl = dds.get(0);
				info.append("<div>" + tl.text().trim() + "</div>");
			}
			Elements ps = div.getElementsByTag("p");
			if (ps.size() > 0) {
				for (Element element : ps) {
					if (element.attr("class").equals("target")) {
						info.append("<div class=\"title\">" + element.text() + "</div>");
					} else {
						info.append("<div>" + element.text() + "</div>");
					}
				}
			}

		}
		jbInfo.setYishibaojian(info.toString());
		return jbInfo;
	}

	/**
	 * 并发症
	 * 
	 * @param url
	 * @param jbInfo
	 * @return
	 * @throws Exception
	 **/
	private JbInfo crawerBFZ(String url, JbInfo jbInfo) throws Exception {

		StringBuffer info = new StringBuffer();
		Document doc = getDocument(url);
		Elements eles = doc.getElementsByClass("links");
		if (eles.size() <= 0) {
			return jbInfo;
		}
		Element dt = eles.get(0);
		info.append("<div>" + dt.text().trim() + "</div>");
		eles = doc.getElementsByTag("dd");
		if (eles.size() > 0) {
			Element dd = doc.getElementsByTag("dd").get(0);
			String cc = dd.html().trim().replace("http://jbk.39.net", "");
			info.append(cc);
		}
		eles = doc.getElementsByClass("art-box");
		if (eles.size() > 0) {
			Elements ps = eles.get(0).getElementsByTag("p");
			if (ps.size() > 0) {
				for (Element element : ps) {
					if (element.attr("class").equals("target")) {
						info.append("<div class=\"title\">" + element.text() + "</div>");
					} else {
						info.append("<div>" + element.text() + "</div>");
					}
				}
			}
		}
		jbInfo.setBingfazheng(info.toString());
		return jbInfo;
	}

	@Override
	public JbInfo querySimpleJbinfo(String daima) {
		JbInfoExample exa = new JbInfoExample();
		exa.createCriteria().andDaimaEqualTo(daima);
		List<JbInfo> infos = jbInfoDao.selectByExampleWithBLOBs(exa);
		return infos.size() > 0 ? infos.get(0) : null;
	}
	//zhengzhuang//
	@Override
	public void crawlSymptomInfo(String url) {
		TaskHistoryLog record = new TaskHistoryLog();
		record.setSiteUrl(SITE_URL_);
		record.setTaskType("jb_zhengzhuang");
		record.setTaskUrl(url);
		taskHistoryLogDao.insert(record);
		String templete_url = url + "%s";
		try {
			JbZhengzhuang jbZhengzhuang= 	crawerZhengzhuang(url);
			crawerQIYIN(String.format(templete_url, "zzqy"),jbZhengzhuang);	
			crawerZHENDUAN(String.format(templete_url, "zdxs"),jbZhengzhuang);	
			crawerJIANCHA(String.format(templete_url, "jcjb"),jbZhengzhuang);	
			crawerJIUZHEN(String.format(templete_url, "jzzn"),jbZhengzhuang);	
			jbZhengzhuangDao.insert(jbZhengzhuang);
		}catch(Exception e){
			e.printStackTrace();
			TaskHistoryLogError log = new TaskHistoryLogError();
			log.setSiteUrl(SITE_URL_);
			log.setStatus(Short.parseShort("0"));
			log.setTaskUrl(url);
			log.setTaskType("jb_zhuangzhuang");
			log.setErrorInfo(e.getMessage());
			taskHistoryLogErrorDao.insert(log);
		}
	}

	private JbZhengzhuang crawerZhengzhuang(String url) throws IOException {
	  JbZhengzhuang jbZhengzhuang=new JbZhengzhuang();
	   Document doc=	getDocument(url);
	   Elements eles=doc.getElementsByClass("tik clearfix");
	   if(eles.size()>0){
		   String daima=getUrlBuwei(url);
		   String mingcheng=eles.get(0).text();
		   jbZhengzhuang.setDaima(daima);
		   jbZhengzhuang.setMingcheng(mingcheng);
	   }
	   Element ele= doc.getElementById("intro");
	   String jianjie=ele.text().trim();
	   jbZhengzhuang.setJianjie(jianjie);
	   
	   eles= doc.getElementsByClass("link clearfix");
	   if(eles.size()>0){
		eles.select(".more").remove();   
		Elements as=  eles.get(0).select("a");
		String fenlei=as.outerHtml().replaceAll("http://jbk.39.net", "").replaceAll("\n", "");
		jbZhengzhuang.setFenlei(fenlei);
	   }
	   eles= doc.getElementsByClass("dis");
	   if(eles.size()>0){
		   Elements  as= eles.get(0).select(".name").select("a");
		   String kenengjibing=as.outerHtml().replaceAll("http://jbk.39.net", "").replaceAll("\n", "");
		   jbZhengzhuang.setKenengjibing(kenengjibing); 
	   }
		return jbZhengzhuang;
	}

	private JbZhengzhuang crawerJIUZHEN(String url, JbZhengzhuang jbZhengzhuang) throws IOException {
		Document doc=getDocument(url);
		Element ele=doc.getElementById("contentText");
		Elements eles=ele.select("dl");
		if(eles.size()>0){
			String jiuzhen=eles.outerHtml();
			jbZhengzhuang.setJiuzhen(jiuzhen);
		}
		return jbZhengzhuang;
	}

	private JbZhengzhuang crawerJIANCHA(String url, JbZhengzhuang jbZhengzhuang) throws IOException {
		StringBuffer buffer=new StringBuffer();
		 Document doc=getDocument(url);
	     Elements eles= doc.getElementsByClass("checkbox-data");
	     buffer.append("<div>常见检查:</div>");
	    if(eles.size()>0){
	    	buffer.append(eles.get(0).html().replaceAll("http://jbk.39.net", ""));
	    }
	   Element ele=doc.getElementById("symList");
	   eles= ele.select("dt").select("a");
	   buffer.append("<div>相似症状:</div>");
	   if(eles.size()>0){
		   String h=eles.outerHtml().replaceAll("http://jbk.39.net", "");
		   buffer.append(h);
	   }
	   jbZhengzhuang.setJiancha(buffer.toString());
		return jbZhengzhuang;
	}

	private JbZhengzhuang crawerZHENDUAN(String url, JbZhengzhuang jbZhengzhuang) throws IOException {
		   Document doc=getDocument(url);
		    Elements eles= doc.getElementsByClass("item catalogItem");
		   if(eles.size()>0){
			   Elements es=eles.select("p");
			   if(es.size()>0){
				   StringBuffer zhenduan=new StringBuffer();
				   for(Element e:es){
					   zhenduan.append("<div>"+StringUtils.deleteWhitespace(e.text())+"</div>");
				   }
					 jbZhengzhuang.setZhenduan(zhenduan.toString().replaceAll("http://jbk.39.net", ""));
			   }
		   }
			return jbZhengzhuang;
	}

	private JbZhengzhuang crawerQIYIN(String url, JbZhengzhuang jbZhengzhuang) throws IOException {
	    Document doc=getDocument(url);
	    Elements eles= doc.getElementsByClass("item catalogItem");
	   if(eles.size()>0){
		   Elements es=eles.select("p");
		   if(es.size()>0){
			   StringBuffer qiyin=new StringBuffer();
			   for(Element e:es){
				   qiyin.append("<div>"+StringUtils.deleteWhitespace(e.text())+"</div>");
			   }
				 jbZhengzhuang.setQiyin(qiyin.toString().replaceAll("http://jbk.39.net", ""));
		   }
	   }
		return jbZhengzhuang;
	}

 
	@Override
	public JbZhengzhuang querySimpleJbZhengzhuang(String daima) {
		JbZhengzhuangExample exa=new JbZhengzhuangExample();
		exa.createCriteria().andDaimaEqualTo(daima);
		List<JbZhengzhuang> zhengzhuangs=jbZhengzhuangDao.selectByExampleWithBLOBs(exa);
		return zhengzhuangs.size()>0?zhengzhuangs.get(0):null;
	}

	
}
