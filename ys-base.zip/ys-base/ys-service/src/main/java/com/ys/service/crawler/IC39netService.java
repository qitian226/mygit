package com.ys.service.crawler;

import com.ys.model.JbInfo;
import com.ys.model.JbZhengzhuang;

public interface IC39netService {
	/**
	 * 
	 * @param beginPage
	 * @param endPage
	 * @throws Exception 
	 */
	public void crawerUrl(int beginPage,int endPage) throws Exception;
/**
 * 
 * @param url
 */
	public void crawlDiseaseInfo(String url);
    /**
     * 
     * @param daima
     * @return
     */
	public JbInfo querySimpleJbinfo(String daima);
     /**
      * 
      * @param url
      */
	public void crawlSymptomInfo(String url);
	/**
	 * 
	 * @param daima
	 * @return
	 */
	public JbZhengzhuang querySimpleJbZhengzhuang(String daima);
}
