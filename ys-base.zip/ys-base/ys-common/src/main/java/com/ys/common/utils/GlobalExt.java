package com.ys.common.utils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.beetl.core.GroupTemplate;
import org.beetl.core.Template;
import org.beetl.ext.web.WebRenderExt;

public class GlobalExt implements WebRenderExt{

	static long version = System.currentTimeMillis();
	static String sitePath;
	@Override
	public void modify(Template template, GroupTemplate arg1, HttpServletRequest request, HttpServletResponse response) {
		response.setBufferSize(1024*24);
		//js,css 的版本编号
		template.binding("version",version);
		String path = request.getContextPath();
		String sitePath = request.getScheme() + "://"
				+ request.getServerName() + ":" + request.getServerPort()
				+ path+"/";
		template.binding("sitePath",sitePath);
	}

}
