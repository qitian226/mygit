package com.ys.controller.crawer;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.ys.model.JbInfo;
import com.ys.model.JbZhengzhuang;
import com.ys.service.crawler.IC39netService;

@RestController
public class C39netController {
@Resource
private IC39netService c39netService;

final String diseaseBaseUrl="http://jbk.39.net/bw";

@RequestMapping(value="/www39net.html")
public ModelAndView goCrawlDisease(){
	ModelAndView view=new ModelAndView("www39net");
	return view;
}

@RequestMapping(value="/disease/index")
@ResponseBody
public String crawlDisease(int beginPage,int endPage,int index){
		c39netService.crawerUrl(beginPage,endPage);
	    return "{\"msg\":\"success\",\"index\":\""+index+"\"}";
}

@RequestMapping(value="/disease/info")
@ResponseBody
public String crawlDiseaseInfo(String url){
		c39netService.crawlDiseaseInfo(url);
	    return "{\"msg\":\"success\",\"index\":\""+url+"\"}";
}
@RequestMapping(value="/symptom/info")
@ResponseBody
public String crawlSymptomInfo(String url){
		c39netService.crawlSymptomInfo(url);
	    return "{\"msg\":\"success\",\"index\":\""+url+"\"}";
}
@RequestMapping(value="/jibing/{daima}")
public ModelAndView toDiseaseInfo(@PathVariable String daima){
	ModelAndView view=new ModelAndView("/disease/jibing");
	JbInfo info=c39netService.querySimpleJbinfo(daima);
	view.addObject("info",info);
	return view;
}
@RequestMapping(value="/zhengzhuang/{daima}")
public ModelAndView toDiseaseZhengzhuang(@PathVariable String daima){
	ModelAndView view=new ModelAndView("/disease/zhengzhuang");
	JbZhengzhuang info=c39netService.querySimpleJbZhengzhuang(daima);
	view.addObject("info",info);
	return view;
}
}
